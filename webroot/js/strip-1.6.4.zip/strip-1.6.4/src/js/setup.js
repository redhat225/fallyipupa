var Strip = {
  version: '<%= pkg.version %>'
};
